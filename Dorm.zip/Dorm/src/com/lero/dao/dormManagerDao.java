package com.lero.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.lero.model.DormManager;
import com.lero.model.PageBean;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class dormManagerDao {
	/**
	 * ���ط�ҳList<DormManager>
	 * @return
	 */
	public List<DormManager> dormManagerList(PageBean pageBean,DormManager dormManager) {
		List<DormManager> query=null;
		StringBuffer sqlBuffer = new StringBuffer("select dormManId as dormManagerId,userName,password,dormBuildId,name,sex,tel from t_dormmanager t1 ");
		if(StringUtil.isNotEmpty(dormManager.getName())){
			sqlBuffer.append(" where t1.name like '%"+dormManager.getName()+"%'");
		}else if(StringUtil.isNotEmpty(dormManager.getUserName())){
			sqlBuffer.append(" where t1.userName like '%"+dormManager.getUserName()+"%'");
		}
		if(pageBean!=null){
			sqlBuffer.append(" limit "+pageBean.getStart()+","+pageBean.getPageSize());
		}
		Connection conn =null;
		try {
			String sql=sqlBuffer.toString();
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			BeanListHandler<DormManager> rsh = new BeanListHandler<DormManager>(DormManager.class);
			query = qr.query(conn, sql, rsh);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return query;
	}
	/**
	 * ���ع���Ա����
	 */
	public List<DormManager> DormManagerList(){
		Connection conn =null;
		List<DormManager> query=null;
		try {
			String sql="select dormManId as dormManagerId,userName,password,dormBuildId,name,sex,tel from t_dormmanager";
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			BeanListHandler<DormManager> rsh = new BeanListHandler<DormManager>(DormManager.class);
			query = qr.query(conn, sql, rsh);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return query;
	}
	/**
	 * ����������
	 */
	public int dormManagerCount(){
		Connection conn=null;
		int query=0;
				try {
					conn=DbUtil.getCon();
					QueryRunner qr = new QueryRunner();
					String sql="select count(*) from t_dormmanager";
					ScalarHandler rsh = new ScalarHandler();
					Number sum =(Number)qr.query(conn, sql, rsh);
					query = sum.intValue();
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					DbUtil.closeCon(conn);
				}
		
		return query;
		
	}
	/**
	 * ����ID��ɾ���������Ա
	 * @param dormManagerId
	 * @return
	 */
	public int alterdormManager(int dormManagerId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="delete from t_dormmanager where dormManId=?";
			update = qr.update(conn, sql, dormManagerId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}
	/**
	 * ����ID�Ų����������Ա
	 */
	public DormManager findByID(int dormManagerId){
		Connection conn=null;
		DormManager query=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select dormManId as dormManagerId,userName,password,dormBuildId,name,sex,tel from t_dormmanager where dormManId=?";
			BeanHandler<DormManager> rsh = new BeanHandler<DormManager>(DormManager.class);
			query = qr.query(conn, sql, rsh,dormManagerId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
	}
	/**
	 * �޸��������Ա��Ϣ
	 * @param dormManId
	 * @param username
	 * @param password
	 * @param name
	 * @param sex
	 * @param tel
	 * @return
	 */
	public int  modiffydormManager(int dormManId,String username, String password,
			String name, String sex, String tel) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="update t_dormmanager set userName=?,password=?,name=?,sex=?,tel=? where dormManId=?";
			update = qr.update(conn, sql, username,password,name,sex,tel,dormManId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
		
	}
	
	public int  adddormManager(String username, String password,
			String name, String sex, String tel){
		Connection conn=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="insert into t_dormmanager values(null,?,?,null,?,?,?)";
			int update = qr.update(conn, sql, username,password,name,sex,tel);
			
			return update;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return 0;
	}
	public int addDormBuild(String username, String password,
			String name, String sex, String tel,int dormBuildId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="insert into t_dormmanager values(null,?,?,?,?,?,?)";
			update = qr.update(conn, sql, username,password,dormBuildId,name,sex,tel);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
		
	}
	public List<DormManager> findDormManagerByBuildId(int dormBuildId) {
		Connection conn=null;
		List<DormManager> query=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select dormManId as dormManagerId,userName,password,dormBuildId,name,sex,tel from t_dormmanager where dormBuildId=?";
			BeanListHandler<DormManager> rsh = new BeanListHandler<DormManager>(DormManager.class);
			query = qr.query(conn, sql, rsh,dormBuildId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
		
	}
	/**
	 * �Ƴ��޹�
	 * @param dormBuildId
	 * @param dormManagerId
	 * @return
	 */
	public int removeManager(int dormBuildId, int dormManagerId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="delete from t_dormmanager where dormBuildId=? and dormManId=?";
			update = qr.update(conn, sql, dormBuildId,dormManagerId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}
}
