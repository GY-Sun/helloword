package com.lero.dao;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.lero.model.DormBuild;
import com.lero.model.DormManager;
import com.lero.model.PageBean;
import com.lero.model.Student;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class DormBuildDao {
	/**
	 * 查询楼栋
	 */
	public List<DormBuild> selectDormBuild(){
		Connection conn = null;
		List<DormBuild> query =null;
		try {
			QueryRunner qr = new QueryRunner();
			conn = DbUtil.getCon();
			String sql = "select dormBuildId,dormBuildName,dormBuildDetail as detail from t_dormbuild";
			BeanListHandler<DormBuild> rsh = new BeanListHandler<DormBuild>(DormBuild.class);
			query= qr.query(conn, sql, rsh);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
	}
	/**
	 * 添加宿舍楼
	 * @param params
	 * @return
	 */
	public int addDormBuild(Object ...params) {
		Connection conn=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="insert into t_dormbuild values(null,?,?)";
			int update = qr.update(conn, sql, params);
			return update;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return 0;
		
	}
	public int selectDormBuildCount() {
		Connection conn=null;
		int query=0;
				try {
					conn=DbUtil.getCon();
					QueryRunner qr = new QueryRunner();
					String sql="select count(*) from t_dormbuild";
					ScalarHandler rsh = new ScalarHandler();
					Number sum =(Number)qr.query(conn, sql, rsh);
					query = sum.intValue();
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					DbUtil.closeCon(conn);
				}
		
		return query;
	}
	public List<DormBuild> dormManagerList(PageBean pageBeen,
			DormBuild dormBuild) {
		List<DormBuild> query=null;
		StringBuffer sqlBuffer = new StringBuffer("select dormBuildId,dormBuildName,dormBuildDetail as detail from t_dormbuild t1 ");
		if(StringUtil.isNotEmpty(dormBuild.getDormBuildName())){
			sqlBuffer.append(" where t1.dormBuildName like '%"+dormBuild.getDormBuildName()+"%'");
		}
		if(pageBeen!=null){
			sqlBuffer.append(" limit "+pageBeen.getStart()+","+pageBeen.getPageSize());
		}
		Connection conn =null;
		try {
			String sql=sqlBuffer.toString();
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			BeanListHandler<DormBuild> rsh = new BeanListHandler<DormBuild>(DormBuild.class);
			query = qr.query(conn, sql, rsh);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return query;
	}
	/**
	 * 根据ID修改楼栋信息
	 * @param dormBuildId
	 */
	public int modifyBuildByID(int dormBuildId,String dormBuildName,String dormBuildDetail) {
		Connection conn=null;
		int update = 0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="update t_dormbuild set dormBuildName=?,dormBuildDetail=? where dormBuildId=?";
			update= qr.update(conn, sql,dormBuildName,dormBuildDetail,dormBuildId);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}
	public DormBuild findById(int dormBuildId) {
		Connection conn=null;
		DormBuild query=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select dormBuildId,dormBuildName,dormBuildDetail as detail from t_dormbuild where dormBuildId=?";
			BeanHandler<DormBuild> rsh = new BeanHandler<DormBuild>(DormBuild.class);
			query = qr.query(conn, sql, rsh,dormBuildId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
		
	}
	public int alterDormBuild(int dormBuildId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql1="delete from t_dormbuild where dormBuildId=?";
			update = qr.update(conn, sql1, dormBuildId);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}
}

