package com.lero.dao;

import java.sql.Connection;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.lero.util.DbUtil;

public class loginDao {
	//ʵ�ֵ�¼��֤����
	public String logintest(String type,String userName, String password){
			QueryRunner qr = new QueryRunner();
			Connection conn=null;
			String loginType=null;
			try {
				conn= DbUtil.getCon();
				String sql = null;
				if("admin".equals(type)){
					sql="select count(*) from t_admin where userName=? and password=?";
					loginType="admin";
				}else if("dormManager".equals(type)){
					sql = "select count(*) from t_dormmanager where userName=? and password=?";
					loginType="dormManager";
				}else if("student".equals(type)){
					sql = "select count(*) from t_student where userName=? and password=?";
					loginType="student";
				}
				ScalarHandler rsh = new ScalarHandler();
				Number num = (Number)qr.query(conn, sql, rsh,userName,password);
				int query = num.intValue();
				if(query==1){
					System.out.println("��½�ɹ�");
					return loginType;
					
				}else{
					return "false";
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				DbUtil.closeCon(conn);
			}
			return null;
			
		}
}
