package com.lero.dao;

import java.sql.Connection;
import java.util.Date;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.lero.model.PageBean;
import com.lero.model.Record;
import com.lero.model.Student;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class RecordDao {
	/**
	 * ���ط�ҳ��¼
	 * @param pageBeen
	 * @param stu
	 * @return
	 */
	public List<Record> RecordList(PageBean pageBeen, Record record) {
		List<Record> query=null;
		StringBuffer sqlBuffer = new StringBuffer("select recordId,studentNumber,studentName,dormBuildId,dormName,date,detail from t_record t1 ");
		if(StringUtil.isNotEmpty(record.getStudentName())){
			sqlBuffer.append(" where t1.studentName like '%"+record.getStudentName()+"%'");
		}else if(StringUtil.isNotEmpty(record.getStudentNumber())){
			sqlBuffer.append(" where t1.studentNumber like '%"+record.getStudentNumber()+"%'");
		}else if(StringUtil.isNotEmpty(record.getDormName())){
			sqlBuffer.append(" where t1.dormName like '%"+record.getDormName()+"%'");
		}else if(record.getDormBuildId()!=0){
			sqlBuffer.append(" and t1.dormBuildId like '%"+record.getDormBuildId()+"%'");
		}
		if(pageBeen!=null){
			sqlBuffer.append(" limit "+pageBeen.getStart()+","+pageBeen.getPageSize());
		}
		Connection conn =null;
		try {
			String sql=sqlBuffer.toString();
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			BeanListHandler<Record> rsh = new BeanListHandler<Record>(Record.class);
			query = qr.query(conn, sql, rsh);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return query;
	}

	public int selectRecoreCount() {
		Connection conn=null;
		int query=0;
				try {
					conn=DbUtil.getCon();
					QueryRunner qr = new QueryRunner();
					String sql="select count(*) from t_record";
					ScalarHandler rsh = new ScalarHandler();
					Number sum =(Number)qr.query(conn, sql, rsh);
					query = sum.intValue();
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					DbUtil.closeCon(conn);
				}
		
		return query;
	}

	public int alterRecore(int recordId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql1="delete from t_record where recordId=?";
			update = qr.update(conn, sql1, recordId);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}

	public Record selectRecoreByRecordId(String recordId) {
		Connection conn=null;
		Record query=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select recordId,studentNumber,studentName,dormBuildId,dormName,date,detail from t_record where recordId = ?";
			BeanHandler<Record> rsh = new BeanHandler<Record>(Record.class);
			query = qr.query(conn, sql, rsh,recordId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
		
	}
	/**
	 * ����ѧ���Ų�ѯѧ����Ϣ
	 * @param params
	 * @return
	 */
	private Student selectStuInfo(String numberID){
		Connection conn=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select * from t_student where userName=?";
			BeanHandler<Student> handler = new BeanHandler<Student>(Student.class);
			Student query = qr.query(conn, sql, handler,numberID);
			return query;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return null;
		
	}
	/**
	 * ����ȱ�ڼ�¼
	 * @param params
	 * @return
	 */
	public int addRecord(String studentNumber,String date,String detail) {
		Connection conn=null;
		try {
			conn = DbUtil.getCon();
			Student stuInfo = selectStuInfo(studentNumber);
			String stuName=stuInfo.getName();
			int buildID = stuInfo.getDormBuildId();
			String dormName = stuInfo.getDormName();
			QueryRunner qr = new QueryRunner();
			String sql="insert into t_record values(null,?,?,?,?,?,?)";
			int update = qr.update(conn, sql, studentNumber,stuName,buildID,dormName,date,detail);
			return update;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return 0;
	}

	public int modify(String studentNumber, String date, String detail) {
		Connection conn=null;
		int update =0 ;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql1 = "update t_record set detail=? where studentNumber=? and date=?";
			update = qr.update(conn, sql1,detail,studentNumber,date);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}

}
