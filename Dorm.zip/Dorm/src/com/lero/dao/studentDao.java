package com.lero.dao;

import java.sql.Connection;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.lero.model.DormManager;
import com.lero.model.PageBean;
import com.lero.model.Student;
import com.lero.util.DbUtil;
import com.lero.util.StringUtil;

public class studentDao {

	/**
	 * ����ѧ��
	 * @param params
	 * @return
	 */
	public int addStudent(Object ...params){
		Connection conn=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="insert into t_student values(null,?,?,?,?,?,?,?)";
			int update = qr.update(conn, sql, params);
			return update;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return 0;
	}
	
	/**
	 * ��ѯѧ����¼��
	 * @return
	 */
	public int selectStuCount() {
		Connection conn=null;
		int query=0;
				try {
					conn=DbUtil.getCon();
					QueryRunner qr = new QueryRunner();
					String sql="select count(*) from t_student";
					ScalarHandler rsh = new ScalarHandler();
					Number sum =(Number)qr.query(conn, sql, rsh);
					query = sum.intValue();
					
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					DbUtil.closeCon(conn);
				}
		
		return query;
	}
	/**
	 * ���ط�ҳ��¼
	 * @param pageBeen
	 * @param stu
	 * @return
	 */
	public List<Student> dormManagerList(PageBean pageBeen, Student stu) {
		List<Student> query=null;
		StringBuffer sqlBuffer = new StringBuffer("select studentId,userName as stuNumber,password,name,dormBuildId,dormName,sex,tel from t_student t1 ");
		if(StringUtil.isNotEmpty(stu.getName())){
			sqlBuffer.append(" where t1.name like '%"+stu.getName()+"%'");
		}else if(StringUtil.isNotEmpty(stu.getStuNumber())){
			sqlBuffer.append(" where t1.userName like '%"+stu.getStuNumber()+"%'");
		}else if(StringUtil.isNotEmpty(stu.getDormName())){
			sqlBuffer.append(" where t1.dormName like '%"+stu.getDormName()+"%'");
		}else if(stu.getDormBuildId()!=0){
			sqlBuffer.append(" and t1.dormBuildId like '%"+stu.getDormBuildId()+"%'");
		}
		if(pageBeen!=null){
			sqlBuffer.append(" limit "+pageBeen.getStart()+","+pageBeen.getPageSize());
		}
		Connection conn =null;
		try {
			String sql=sqlBuffer.toString();
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			BeanListHandler<Student> rsh = new BeanListHandler<Student>(Student.class);
			query = qr.query(conn, sql, rsh);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return query;
	}
	/**
	 * ����ID�Ų���ѧ����Ϣ
	 * @param studentId
	 * @return
	 */
	public Student findByID(int studentId) {
		Connection conn=null;
		Student query=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select studentId,userName as stuNumber,password,name,dormBuildId,dormName,sex,tel from t_student where studentId=?";
			BeanHandler<Student> rsh = new BeanHandler<Student>(Student.class);
			query = qr.query(conn, sql, rsh,studentId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
	}
	/**
	 * �޸�ѧ����Ϣ
	 * @param username
	 * @param password
	 * @param name
	 * @param dormBuildId
	 * @param dormName
	 * @param sex
	 * @param tel
	 * @return
	 */
	public int modiffydormManager(String username, String password,
			String name, int dormBuildId, String dormName, String sex,
			String tel,int studentId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="update t_student set userName=?,password=?,name=?,dormBuildId=?,dormName=?,sex=?,tel=? where studentId=?";
			update = qr.update(conn, sql, username,password,name,dormBuildId,dormName,sex,tel,studentId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
		
	}
	/**
	 * ����ѧ��ɾ��ѧ����Ϣ
	 * @param studentId
	 * @return
	 */
	public int alterStudent(int studentId) {
		Connection conn=null;
		int update=0;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql1="delete from t_student where studentId=?";
			update = qr.update(conn, sql1, studentId);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return update;
	}

	public List<Student> selectNumList() {
		Connection conn=null;
		List<Student> query=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="select studentId,userName as stuNumber,password,name,dormBuildId,dormName,sex,tel from t_student";
			BeanListHandler<Student> rsh = new BeanListHandler<Student>(Student.class);
			query = qr.query(conn, sql, rsh);
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return query;
		
	}
}
