package com.lero.dao;

import java.io.DataInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.lero.model.DormBuild;
import com.lero.model.Student;
import com.lero.util.DbUtil;

public class adminDao {

	/**
	 * ���ӹ���Ա
	 * @param params
	 * @return
	 */
	public int  addAdmin(Object ...params){
		Connection conn=null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="insert into t_admin values(null,?,?,?,?,?)";
			int update = qr.update(conn, sql, params);
			return update;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return 0;
	}
	
	
	
	//�޸�����
	public int alterPassword(String currentUser,String password,String table) {
		Connection conn = null;
		try {
			conn = DbUtil.getCon();
			QueryRunner qr = new QueryRunner();
			String sql="update "+table+" set password=? where userName=? ";
			int execute = qr.update(conn, sql, password,currentUser);
			return execute;
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DbUtil.closeCon(conn);
		}
		return 0;
	}



	
}
