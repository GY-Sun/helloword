package com.lero.web;

import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.DormBuildDao;
import com.lero.dao.RecordDao;
import com.lero.dao.adminDao;
import com.lero.dao.studentDao;
import com.lero.model.DormBuild;
import com.lero.model.PageBean;
import com.lero.model.Record;
import com.lero.model.Student;
import com.lero.util.DateUtil;
import com.lero.util.StringUtil;

public class RecordServlet extends HttpServlet {
	String userType;
	String type=null;
	String flag;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		userType = new LoginServlet().userType;
	
		if("admin".equals(userType)){
			type = "mainAdmin";
		}else if("dormManager".equals(userType)){
			type = "mainManager";
		}else if("student".equals(userType)){
			type = "mainStudent";
		}
		String page = req.getParameter("page");
		String action = req.getParameter("action");
		if("preSave".equals(action)){
			String typed = null;
			Enumeration parameterNames = req.getParameterNames();
			while(parameterNames.hasMoreElements()){
				typed = (String)parameterNames.nextElement();
			}
			if("studentNumber".equals(typed)){
				flag="add";
				String stuNum = req.getParameter("studentNumber");
				req.setAttribute("studentNumber", stuNum);
			}else if("recordId".equals(typed)){
				flag="modify";
				String recordId = req.getParameter("recordId");
				RecordDao dao = new RecordDao();
				Record record = dao.selectRecoreByRecordId(recordId);
				req.setAttribute("record", record);
			}
			
			req.setAttribute("mainPage", userType+"/recordSave.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
			
		}else if("list".equals(action)){
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			stucha(req,resp,page);
		}else if("delete".equals(action)){
			int recordId = Integer.parseInt(req.getParameter("recordId"));
			RecordDao dao = new RecordDao();
			int alter = dao.alterRecore(recordId);
			if(alter>0){
				req.setAttribute("error", "ɾ���ɹ�");
				req.setAttribute("mainPage", userType+"/record.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
			
		}
		tong(req,resp, page);
		}
	
	/**
	 * ͨ�õ�ǰ����ʾҳ��
	 */
	private String genPagation(int totalNum,int currentPage,int pageSize){
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='record?page=1'>��ҳ</a></li>");
		
		if(currentPage==1){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='record?page="+(currentPage-1)+"'>��һҳ</a></li>");
		}
		for(int i=currentPage-2;i<=currentPage+2;i++){
			if(i<1||i>totalPage){
				continue;
			}
			if(i==currentPage){
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			}else{
				pageCode.append("<li><a href='record?page="+i+"'>"+i+"</a></li>");
			}
		}
		if(currentPage==totalPage){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='record?page="+(currentPage+1)+"'>��һҳ</a></li>");
		}
		pageCode.append("<li><a href='record?page="+totalPage+"'>βҳ</a></li>");
		return pageCode.toString();
		
	}
	//ѧ���鿴
	public void stucha(HttpServletRequest req, HttpServletResponse resp,String page)
			throws ServletException, IOException{
		if(StringUtil.isEmpty(page)){
			return;
		}
		
		HttpSession session = req.getSession();
		String stuNum = (String)session.getAttribute("currentUser");
		Record record = new Record();
		record.setStudentNumber(stuNum);
		studentDao dao = new studentDao();
		List<Student> selectNumList = dao.selectNumList();
		
		for(Student stu:selectNumList){
			if(stuNum.equals(stu.getStuNumber())){
				System.out.println(stuNum+"ssss");
				PageBean pageBeen = new PageBean(Integer.parseInt(page), 5);
				req.setAttribute("pageSize", pageBeen.getPageSize());
				req.setAttribute("page", pageBeen.getPage());
				RecordDao dao1 = new RecordDao();
				int totalNum = dao1.selectRecoreCount();
				String pageCode = genPagation(totalNum,pageBeen.getPage(),pageBeen.getPageSize());
				
				List<Record> list = dao1.RecordList(pageBeen, record);
				req.setAttribute("pageCode", pageCode);
				req.setAttribute("recordList", list);

				req.setAttribute("mainPage", userType+"/record.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
				break;
			}
		}
		
		
	}
	
	public void tong(HttpServletRequest req, HttpServletResponse resp,String page)
			throws ServletException, IOException{
		if(StringUtil.isEmpty(page)){
			return;
		}
		//��¥���ŷ���ǰ̨ҳ��
		DormBuildDao dao = new DormBuildDao();
		List<DormBuild> selectDormBuild = dao.selectDormBuild();
		req.setAttribute("dormBuildList", selectDormBuild);
		//��ȡ��������
		String buildToSelect = req.getParameter("buildToSelect");
		String searchType = req.getParameter("searchType");
		String value = req.getParameter("s_studentText");
		Record record = new Record();
		
		System.out.println(page);
		if(StringUtil.isNotEmpty(value)&&StringUtil.isNotEmpty(searchType)){
			if("name".equals(searchType)){
				record.setStudentName(value);
			}else if("number".equals(searchType)){
				record.setStudentNumber(value);
			}else if("dorm".equals(searchType)){
				record.setDormName(value);
			}
			
		
		}
		if(StringUtil.isNotEmpty(buildToSelect)){
			record.setDormBuildId(Integer.parseInt(buildToSelect));
		}	
		PageBean pageBeen = new PageBean(Integer.parseInt(page), 5);
		req.setAttribute("pageSize", pageBeen.getPageSize());
		req.setAttribute("page", pageBeen.getPage());
		RecordDao dao1 = new RecordDao();
		int totalNum = dao1.selectRecoreCount();
		String pageCode = genPagation(totalNum,pageBeen.getPage(),pageBeen.getPageSize());
		
		List<Record> list = dao1.RecordList(pageBeen, record);
		req.setAttribute("pageCode", pageCode);
		req.setAttribute("recordList", list);

		req.setAttribute("mainPage", userType+"/record.jsp");
		req.getRequestDispatcher(type+".jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String action = req.getParameter("action");

		if("save".equals(action)){
			String studentNumber = req.getParameter("studentNumber");
			String date = DateUtil.formatDate(new Date(), "yyyy-MM-dd");
			String detail = req.getParameter("detail");
			
			
			if("add".equals(flag)){
				RecordDao dao = new RecordDao();
				int addAdmin = dao.addRecord(studentNumber,date,detail);
				if(addAdmin!=0){
					req.setAttribute("error", "���ӳɹ�");
					req.setAttribute("mainPage", userType+"/record.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}else if("modify".equals(flag)){
				System.out.println(studentNumber);
				System.out.println(date);
				System.out.println(detail);
				RecordDao dao = new RecordDao();
				int addAdmin = dao.modify(studentNumber,date,detail);
				if(addAdmin!=0){
					req.setAttribute("error", "�޸ĳɹ�");
					req.setAttribute("mainPage", userType+"/record.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}
		}else if("search".equals(action)){
			String page =null;
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			tong(req, resp, page);
		}
	}
}
