package com.lero.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lero.dao.DormBuildDao;
import com.lero.dao.adminDao;
import com.lero.dao.dormManagerDao;
import com.lero.dao.studentDao;
import com.lero.model.DormBuild;
import com.lero.model.DormManager;
import com.lero.model.PageBean;
import com.lero.model.Student;
import com.lero.util.StringUtil;

public class StudentServlet extends HttpServlet {
	int studentId;
	String userType ;
	String type=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		userType= new LoginServlet().userType;
		
		
		if("admin".equals(userType)){
			type = "mainAdmin";
		}else if("dormManager".equals(userType)){
			type = "mainManager";
		}else if("student".equals(userType)){
			type = "mainStudent";
		}
		String page = req.getParameter("page");
		String action = req.getParameter("action");
		
		if("preSave".equals(action)){
			if(req.getParameter("studentId")==null){
				DormBuildDao dao = new DormBuildDao();
				List<DormBuild> list = dao.selectDormBuild();
				req.setAttribute("dormBuildList", list);
				req.setAttribute("mainPage", userType+"/studentSave.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}else{
				DormBuildDao dao = new DormBuildDao();
				List<DormBuild> list = dao.selectDormBuild();
				req.setAttribute("dormBuildList", list);
				studentId = Integer.parseInt(req.getParameter("studentId"));
				studentDao dao1 = new studentDao();
				Student stu= dao1.findByID(studentId);
				req.setAttribute("student", stu);
				req.setAttribute("mainPage", userType+"/studentSave.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
		}else if("list".equals(action)){
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			/*req.setAttribute("mainPage", userType+"/student.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);*/
		}else if("delete".equals(action)){
			int studentId = Integer.parseInt(req.getParameter("studentId"));
			studentDao dao = new studentDao();
			int alter = dao.alterStudent(studentId);
			if(alter>0){
				req.setAttribute("error", "ɾ���ɹ�");
				req.setAttribute("mainPage", userType+"/student.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
			
		}
		tong(req,resp, page);
	}
	public void tong(HttpServletRequest req, HttpServletResponse resp,String page)
			throws ServletException, IOException{
		if(StringUtil.isEmpty(page)){
			return;
		}
		//��¥���ŷ���ǰ̨ҳ��
		DormBuildDao dao = new DormBuildDao();
		List<DormBuild> selectDormBuild = dao.selectDormBuild();
		req.setAttribute("dormBuildList", selectDormBuild);
		//��ȡ��������
		String buildToSelect = req.getParameter("buildToSelect");
		String searchType = req.getParameter("searchType");
		String value = req.getParameter("s_studentText");
		Student stu = new Student();
		
		System.out.println(page);
		if(StringUtil.isNotEmpty(value)&&StringUtil.isNotEmpty(searchType)){
			if("name".equals(searchType)){
				stu.setName(value);
			}else if("number".equals(searchType)){
				stu.setStuNumber(value);
			}else if("dorm".equals(searchType)){
				stu.setDormName(value);
			}
			
		
		}
		if(StringUtil.isNotEmpty(buildToSelect)){
			stu.setDormBuildId(Integer.parseInt(buildToSelect));
		}	
		
		
		PageBean pageBeen = new PageBean(Integer.parseInt(page), 5);
		req.setAttribute("pageSize", pageBeen.getPageSize());
		req.setAttribute("page", pageBeen.getPage());
		studentDao dao1 = new studentDao();
		int totalNum = dao1.selectStuCount();
		String pageCode = genPagation(totalNum,pageBeen.getPage(),pageBeen.getPageSize());
		
		List<Student> list = dao1.dormManagerList(pageBeen, stu);
		req.setAttribute("pageCode", pageCode);
		req.setAttribute("studentList", list);
		
		req.setAttribute("mainPage", userType+"/student.jsp");
		req.getRequestDispatcher(type+".jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String action = req.getParameter("action");

		if("save".equals(action)){
			
			String username = req.getParameter("userName");
			String password = req.getParameter("password");
			String name = req.getParameter("name");
			String sex = null ;
			if(req.getParameter("sex")!=""){
				sex = req.getParameter("sex");
			}
			int dormBuildId = Integer.parseInt(req.getParameter("dormBuildId"));
			String dormName = req.getParameter("dormName");
			
			String tel = req.getParameter("tel");
			
		    studentDao dao = new studentDao();
			
			//�ж������Ӳ��������޸Ĳ���
			int flag=0;
			if(StringUtil.isNotEmpty(String.valueOf(studentId))){
				flag = dao.modiffydormManager(username,password,name,dormBuildId,dormName,sex,tel,studentId);
				if(flag!=0){
					req.setAttribute("error", "�޸ĳɹ�");
					req.setAttribute("mainPage", userType+"/student.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}else{
				flag = dao.addStudent(username,password,name,dormBuildId,dormName,sex,tel);
				if(flag!=0){
					req.setAttribute("error", "ɾ���ɹ�");
					req.setAttribute("mainPage", userType+"/student.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}
			
			
		}
		if("search".equals(action)){
			String page =null;
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			tong(req, resp, page);
		}
	}
	/**
	 * ͨ�õ�ǰ����ʾҳ��
	 */
	private String genPagation(int totalNum,int currentPage,int pageSize){
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='student?page=1'>��ҳ</a></li>");
		
		if(currentPage==1){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='student?page="+(currentPage-1)+"'>��һҳ</a></li>");
		}
		for(int i=currentPage-2;i<=currentPage+2;i++){
			if(i<1||i>totalPage){
				continue;
			}
			if(i==currentPage){
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			}else{
				pageCode.append("<li><a href='student?page="+i+"'>"+i+"</a></li>");
			}
		}
		if(currentPage==totalPage){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='student?page="+(currentPage+1)+"'>��һҳ</a></li>");
		}
		pageCode.append("<li><a href='student?page="+totalPage+"'>βҳ</a></li>");
		return pageCode.toString();
		
	}
}
