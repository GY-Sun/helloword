package com.lero.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.adminDao;

public class PasswordServlet extends HttpServlet {
	String type;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String userType = new LoginServlet().userType;
		req.setAttribute("mainPage", userType+"/passwordChange.jsp");
		if("admin".equals(userType)){
			type = "mainAdmin";
		}else if("dormManager".equals(userType)){
			type = "mainManager";
		}else if("student".equals(userType)){
			type = "mainStudent";
		}

		String action = req.getParameter("action");
		if("preChange".equals(action)){
			HttpSession session = req.getSession();
			String password = (String)session.getAttribute("password");
			System.out.println(password);
			session.setAttribute("oldPassword", password);
			req.setAttribute("mainPage", userType+"/passwordChange.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
			
		}
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String action = req.getParameter("action");

		String userType = new LoginServlet().userType;
		String table=null;
		if("admin".equals(userType)){
			table = "t_admin";
		}else if("dormManager".equals(userType)){
			table = "t_dormmanager";
		}else if("student".equals(userType)){
			table = "t_student";
		}
		
		
		
		if("change".equals(action)){
			
			String password = req.getParameter("rPassword");
			
			adminDao dao = new adminDao();
			HttpSession session = req.getSession();
			String currentUser = (String) session.getAttribute("currentUser");
			
			int addAdmin = dao.alterPassword(currentUser,password,table);
			if(addAdmin!=0){
				req.setAttribute("error", "�޸ĳɹ�");
				req.setAttribute("mainPage", userType+"/passwordChange.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
		}
	}
}
