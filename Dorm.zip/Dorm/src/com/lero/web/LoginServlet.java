package com.lero.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lero.dao.loginDao;

public class LoginServlet extends HttpServlet {
	static String userType;
	private String userName;
	private String password;
	private String remember;
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		userName = req.getParameter("userName");
		password = req.getParameter("password");
		userType = req.getParameter("userType");
		remember = req.getParameter("remember");
		
		if("remember-me".equals(remember)){
			//����Cookie
			Cookie cookiename = new Cookie("username", userName);
			Cookie cookiepass= new Cookie("password", password);
			cookiename.setMaxAge(60*60*24*7);
			cookiepass.setMaxAge(60*60*24*7);
			resp.addCookie(cookiepass);
			resp.addCookie(cookiename);
		}
		loginDao logindao = new loginDao();
		String logintType = logindao.logintest(userType, userName, password);
		HttpSession session = req.getSession();
		session.setAttribute("currentUser", userName);
		session.setAttribute("password", password);
		if("admin".equals(logintType)){
			req.getRequestDispatcher("mainAdmin.jsp").forward(req, resp);
		}else if("dormManager".equals(logintType)){
			req.getRequestDispatcher("mainManager.jsp").forward(req, resp);
		}else if("student".equals(logintType)){
			req.getRequestDispatcher("mainStudent.jsp").forward(req, resp);
		}else if("false".equals(logintType)){
			req.setAttribute("error", "������Ϣ����ȷ��������");
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}
		
	}
}
