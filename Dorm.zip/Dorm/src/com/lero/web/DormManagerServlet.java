package com.lero.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lero.dao.adminDao;
import com.lero.dao.dormManagerDao;
import com.lero.model.DormManager;
import com.lero.model.PageBean;
import com.lero.util.StringUtil;

public class DormManagerServlet extends HttpServlet {
	int dormManagerId;
	String userType ;
	String type=null;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		userType= new LoginServlet().userType;
		if("admin".equals(userType)){
			type = "mainAdmin";
		}else if("dormManager".equals(userType)){
			type = "mainManager";
		}else if("student".equals(userType)){
			type = "mainStudent";
		}
		String page = req.getParameter("page");
		String action = req.getParameter("action");
		if("preSave".equals(action)){
			if(req.getParameter("dormManagerId")==null){
				req.setAttribute("mainPage", userType+"/dormManagerSave.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}else{
			dormManagerId = Integer.parseInt(req.getParameter("dormManagerId"));
			dormManagerDao dao = new dormManagerDao();
			System.out.println("id:"+dormManagerId);
			DormManager dormManager= dao.findByID(dormManagerId);
			req.setAttribute("dormManager", dormManager);
			req.setAttribute("mainPage", userType+"/dormManagerSave.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
		}else if("list".equals(action)){
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			//tong(req,resp,page);
		}else if("delete".equals(action)){
			int dormManagerId = Integer.parseInt(req.getParameter("dormManagerId"));
			dormManagerDao dao = new dormManagerDao();
			int alterdormManager = dao.alterdormManager(dormManagerId);
			req.setAttribute("error", "ɾ���ɹ�");
			req.setAttribute("mainPage", userType+"/dormManager.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
		}
		
		tong(req,resp,page);
		
	}
	public void tong(HttpServletRequest req, HttpServletResponse resp,String page)
			throws ServletException, IOException{
		if(StringUtil.isEmpty(page)){
			return;
		}
		System.out.println(page);
		String searchType = req.getParameter("searchType");
		String value = req.getParameter("s_dormManagerText");
		DormManager dormManager = new DormManager();
		
		System.out.println(page);
		if(searchType!=""||searchType!=null){
			if("name".equals(searchType)){
				dormManager.setName(value);
			}else if("userName".equals(searchType)){
				dormManager.setUserName(value);
			}
		}
		/*if(StringUtil.isEmpty(page)){
			page="1";
		}*/
		PageBean pageBeen = new PageBean(Integer.parseInt(page), 5);
		req.setAttribute("pageSize", pageBeen.getPageSize());
		req.setAttribute("page", pageBeen.getPage());
		dormManagerDao dao = new dormManagerDao();
		int totalNum = dao.dormManagerCount();
		String pageCode = genPagation(totalNum,pageBeen.getPage(),pageBeen.getPageSize());
		
		List<DormManager> list = dao.dormManagerList(pageBeen, dormManager);
		req.setAttribute("pageCode", pageCode);
		req.setAttribute("dormManagerList", list);
		/*req.setAttribute("mainPage", "admin/dormManager.jsp");
		req.getRequestDispatcher("mainAdmin.jsp").forward(req, resp);
		*/
		req.setAttribute("mainPage", userType+"/dormManager.jsp");
		req.getRequestDispatcher(type+".jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String action = req.getParameter("action");
		
		
		if("save".equals(action)){
			String username = req.getParameter("userName");
			String password = req.getParameter("password");
			String name = req.getParameter("name");
			String sex = null ;
			if(req.getParameter("sex")!=""){
				sex = req.getParameter("sex");
			}
			String tel = req.getParameter("tel");
			int flag=0;
			dormManagerDao dso = new dormManagerDao();
			if(StringUtil.isNotEmpty(String.valueOf(dormManagerId))){
				flag = dso.modiffydormManager(dormManagerId,username,password,name,sex,tel);
				if(flag>0){
					req.setAttribute("error", "�޸ĳɹ�");
					req.setAttribute("mainPage", userType+"/dormManager.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
				
			}else{
				flag = dso.adddormManager(username, password, name, sex, tel);
				if(flag>0){
					req.setAttribute("error", "���ӳɹ�");
					req.setAttribute("mainPage", userType+"/dormManager.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}
			
		}
		if("search".equals(action)){
			String page = req.getParameter("page");
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			tong(req, resp, page);
		}
		
	}
	private String genPagation(int totalNum,int currentPage,int pageSize){
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='dormManager?page=1'>��ҳ</a></li>");
		
		if(currentPage==1){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='dormManager?page="+(currentPage-1)+"'>��һҳ</a></li>");
		}
		for(int i=currentPage-2;i<=currentPage+2;i++){
			if(i<1||i>totalPage){
				continue;
			}
			if(i==currentPage){
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			}else{
				pageCode.append("<li><a href='dormManager?page="+i+"'>"+i+"</a></li>");
			}
		}
		if(currentPage==totalPage){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='dormManager?page="+(currentPage+1)+"'>��һҳ</a></li>");
		}
		pageCode.append("<li><a href='dormManager?page="+totalPage+"'>βҳ</a></li>");
		return pageCode.toString();
		
	}
}
