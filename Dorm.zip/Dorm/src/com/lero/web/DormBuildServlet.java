package com.lero.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lero.dao.DormBuildDao;
import com.lero.dao.adminDao;
import com.lero.dao.dormManagerDao;
import com.lero.dao.studentDao;
import com.lero.model.DormBuild;
import com.lero.model.DormManager;
import com.lero.model.PageBean;
import com.lero.model.Student;
import com.lero.util.StringUtil;

public class DormBuildServlet extends HttpServlet {
	String userType ;
	String type=null;
	int dormBuildId;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		userType = new LoginServlet().userType;
		
		if("admin".equals(userType)){
			type = "mainAdmin";
		}else if("dormManager".equals(userType)){
			type = "mainManager";
		}else if("student".equals(userType)){
			type = "mainStudent";
		}
		String page = req.getParameter("page");
		String action = req.getParameter("action");
		if("preSave".equals(action)){
			if(req.getParameter("dormBuildId")==null){
				req.setAttribute("mainPage", userType+"/dormBuildSave.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}else{
				//����ID�޸���Ϣ
				dormBuildId = Integer.parseInt(req.getParameter("dormBuildId"));
				DormBuildDao dao = new DormBuildDao();
				DormBuild findBuildById = dao.findById(dormBuildId);
				req.setAttribute("dormBuild", findBuildById);
				req.setAttribute("mainPage", userType+"/dormBuildSave.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
		}else if("list".equals(action)){
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			
		}else if("manager".equals(action)){
			//��ʾ����Ա����
			String dormBuildId = req.getParameter("dormBuildId");
			req.setAttribute("dormBuildId", dormBuildId);
			dormManagerDao dao = new dormManagerDao();
			List<DormManager> dormManagerList = dao.DormManagerList();
			req.setAttribute("managerListToSelect", dormManagerList);
			//����¥���Ž�����Ա��Ϣ��ʾ����
			List<DormManager> DormManagerByBuildId = dao.findDormManagerByBuildId(Integer.parseInt(dormBuildId));
			req.setAttribute("managerListWithId", DormManagerByBuildId);
			req.setAttribute("mainPage", userType+"/selectManager.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
			
		}else if("move".equals(action)){
			int dormBuildId = Integer.parseInt(req.getParameter("dormBuildId"));
			int dormManagerId = Integer.parseInt(req.getParameter("dormManagerId"));
			dormManagerDao dao = new dormManagerDao();
			int flag = dao.removeManager(dormBuildId,dormManagerId);
			if(flag>0){
				req.setAttribute("error", "�Ƴ��ɹ�");
			}
			req.setAttribute("mainPage", userType+"/selectManager.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
		}else if("delete".equals(action)){
			int dormBuildId = Integer.parseInt(req.getParameter("dormBuildId"));
			DormBuildDao dao = new DormBuildDao();
			int alter = dao.alterDormBuild(dormBuildId);
			if(alter>0){
				req.setAttribute("error", "ɾ���ɹ�");
				req.setAttribute("mainPage", userType+"/dormBuild.jsp");
				req.getRequestDispatcher(type+".jsp").forward(req, resp);
			}
			
		}
		//dormBuild?action=move&dormBuildId=1&dormManagerId=3
		tong(req,resp, page);
		
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String action = req.getParameter("action");

		if("save".equals(action)){
			String dormBuildName = req.getParameter("dormBuildName");
			String detail = req.getParameter("detail");
		
			DormBuildDao dao = new DormBuildDao();
			//�ж������Ӳ��������޸Ĳ���
			int flag=0;
			if(StringUtil.isNotEmpty(String.valueOf(dormBuildId))){
				flag = dao.modifyBuildByID(dormBuildId,dormBuildName,detail);
				if(flag!=0){
					req.setAttribute("error", "�޸ĳɹ�");
					req.setAttribute("mainPage", userType+"/selectManager.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}else{
				flag = dao.addDormBuild(dormBuildName,detail);
				if(flag!=0){
					req.setAttribute("error", "���ӳɹ�");
					req.setAttribute("mainPage", userType+"/selectManager.jsp");
					req.getRequestDispatcher(type+".jsp").forward(req, resp);
				}
			}
			
			
		}else if("search".equals(action)){
			String page =null;
			if(StringUtil.isEmpty(page)){
				page="1";
			}
			tong(req, resp, page);
		}else if("addManager".equals(action)){
			int dormBuildId = Integer.parseInt(req.getParameter("dormBuildId"));
			int dormManagerId = Integer.parseInt(req.getParameter("dormManagerId"));
			dormManagerDao dao = new dormManagerDao();
			DormManager findByID = dao.findByID(dormManagerId);
			int addDormBuild = dao.addDormBuild(findByID.getUserName(),findByID.getPassword(),findByID.getName(),findByID.getSex(),findByID.getTel(),dormBuildId);
			if(addDormBuild>0){
				req.setAttribute("error", "���ӳɹ�");
			}
			req.setAttribute("mainPage", userType+"/selectManager.jsp");
			req.getRequestDispatcher(type+".jsp").forward(req, resp);
		}
		
	}
	public void tong(HttpServletRequest req, HttpServletResponse resp,String page)
			throws ServletException, IOException{
		if(StringUtil.isEmpty(page)){
			return;
		}
		//��ȡ��������
		String value = req.getParameter("s_dormBuildName");
		DormBuild dormBuild = new DormBuild();
		
		System.out.println(page);
		if(StringUtil.isNotEmpty(value)){
			dormBuild.setDormBuildName(value);
		}

		PageBean pageBeen = new PageBean(Integer.parseInt(page), 5);
		req.setAttribute("pageSize", pageBeen.getPageSize());
		req.setAttribute("page", pageBeen.getPage());
		DormBuildDao dao = new DormBuildDao();
		int totalNum = dao.selectDormBuildCount();
		String pageCode = genPagation(totalNum,pageBeen.getPage(),pageBeen.getPageSize());
		
		List<DormBuild> list = dao.dormManagerList(pageBeen, dormBuild);
		req.setAttribute("pageCode", pageCode);
		req.setAttribute("dormBuildList", list);
	
		req.setAttribute("mainPage", userType+"/dormBuild.jsp");
		req.getRequestDispatcher(type+".jsp").forward(req, resp);
	}
	/**
	 * ͨ�õ�ǰ����ʾҳ��
	 */
	private String genPagation(int totalNum,int currentPage,int pageSize){
		int totalPage = totalNum%pageSize==0?totalNum/pageSize:totalNum/pageSize+1;
		StringBuffer pageCode = new StringBuffer();
		pageCode.append("<li><a href='dormBuild?page=1'>��ҳ</a></li>");
		
		if(currentPage==1){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='dormBuild?page="+(currentPage-1)+"'>��һҳ</a></li>");
		}
		for(int i=currentPage-2;i<=currentPage+2;i++){
			if(i<1||i>totalPage){
				continue;
			}
			if(i==currentPage){
				pageCode.append("<li class='active'><a href='#'>"+i+"</a></li>");
			}else{
				pageCode.append("<li><a href='dormBuild?page="+i+"'>"+i+"</a></li>");
			}
		}
		if(currentPage==totalPage){
			pageCode.append("<li class='disabled'><a href='#'>��һҳ</a></li>");
		}else{
			pageCode.append("<li><a href='dormBuild?page="+(currentPage+1)+"'>��һҳ</a></li>");
		}
		pageCode.append("<li><a href='dormBuild?page="+totalPage+"'>βҳ</a></li>");
		return pageCode.toString();
		
	}
}
