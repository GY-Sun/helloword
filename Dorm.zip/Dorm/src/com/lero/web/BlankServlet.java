package com.lero.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BlankServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String userType = new LoginServlet().userType;
		String type=null;
		if("admin".equals(userType)){
			type = "mainAdmin";
		}else if("dormManager".equals(userType)){
			type = "mainManager";
		}else if("student".equals(userType)){
			type = "mainStudent";
		}
		req.setAttribute("mainPage", userType+"/blank.jsp");
		req.getRequestDispatcher(type+".jsp").forward(req, resp);
	}
}
